package question1;

//My Shape is an abstract class with an abstract Draw method
public abstract class MyShape {

    abstract void draw();
}