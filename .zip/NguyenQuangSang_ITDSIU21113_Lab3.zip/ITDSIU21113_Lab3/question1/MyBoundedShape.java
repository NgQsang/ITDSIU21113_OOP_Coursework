package question1;

// MyBoundedShape is an abstract class that extends MyShape
// It has an abstract method getArea()
public abstract class MyBoundedShape extends MyShape {
    public abstract float GetArea();
}
