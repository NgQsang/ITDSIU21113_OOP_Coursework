package question4;

//testing
public class Main {
    public static void main(String[] args) {

        //creating objects
        Point2D p2d = new Point2D(14, 30);
        Point3D p3d = new Point3D(10, 20, 30);

        // printing
        //2D
        System.out.println(p2d.toString());
        //3D
        System.out.println(p3d.toString());
    }
}
